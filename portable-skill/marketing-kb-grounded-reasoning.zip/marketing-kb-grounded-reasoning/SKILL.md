---
name: marketing-kb-grounded-reasoning
description: Use when an agent must answer a substantive marketing question from
  the approved OpenKnowledge corpus, including questions phrased in the user's
  own language. Apply it before answering to resolve the corpus boundary,
  retrieve detailed records, compare their conditions with the user's situation,
  and state limits and missing information.
---
# Marketing knowledge grounded reasoning

Use this skill when a consultant asks a substantive marketing question and an approved marketing corpus is available through OpenKnowledge MCP.

## Authority and access

Treat the approved corpus as the authority for general marketing principles. User-provided material may establish situation facts. Clearly label assumptions and inference. Do not use model memory as authority for a material marketing conclusion.

Use the corpus only through OpenKnowledge MCP. Respect the host's permitted tool set.

This release is read-only. The host or gateway blocks tools that create, edit, move, or delete knowledge. Do not attempt a write operation even if a write tool is visible.

## Resolve the corpus boundary

1. Read the effective OpenKnowledge `content.dir` once at the start of the task and treat it as the corpus root.
2. Search result paths may be relative to the corpus root, while a lower-level reader such as `exec` may require a repository-relative path. Do not assume every MCP tool uses the same path namespace.
3. Validate that a search result belongs inside the corpus, then convert it for the read tool. If `content.dir` is `knowledge` and search returns `chapter-02/record`, use `knowledge/chapter-02/record.md` with `exec`. If the result already begins with `knowledge/`, do not add the prefix again.
4. Reject absolute paths, `../` traversal, setup, testing, release-administration, portable-skill, and agent-skill/runtime paths.
5. If the path form is ambiguous, resolve the configuration and test one known record before reading further.
6. When auditing, omit the path to audit the configured corpus. Do not pass `knowledge` as a child path when `content.dir` is already `knowledge`.

## Route every turn

Before replying, decide whether the turn is substantive marketing, administrative, a correction, or a request to use an outside tool.

For substantive marketing turns, perform a fresh knowledge check. Reuse a previously read record only after confirming that it remains relevant. Administrative turns need no marketing retrieval.

## Retrieve and apply

1. Translate the consultant's wording into candidate marketing concepts. If the interpretation would materially change the answer, say how you understood it or ask a clarifying question.
2. Use a navigation record or authority map to orient the search when the question could match several concepts.
3. Search using the original wording and useful alternatives.
4. Discard results outside the resolved corpus root.
5. Read detailed records rather than relying on search snippets. Follow navigation links only when conditions or limits need checking.
6. If the first search is weak, reformulate once before concluding that the corpus lacks support.
7. Compare each relevant record's conditions with established situation facts and identify missing information.
8. Give a direct conversational answer. Name the concepts or records that shaped it, explain what they mean here, separate facts from assumptions and inference, and ask one safest useful next question.

If no adequate authority is found, say so plainly, explain the limit, ask one focused question, and offer a safe alternative. If the answer needs outside evidence, explain what is missing and ask permission before a separately configured outside-tool step.

## Protect the context window

Use a small retrieval budget for each turn:

- Request about 5–10 search results.
- Read only the 2–4 detailed records most relevant to the question.
- Make at most one short reformulated search when the first search is weak.
- Prefer targeted reads, snippets, links, and concise notes over directory dumps or full chapters.
- Stop retrieving when the evidence supports the answer, its limits, and one useful next question.

Do not retrieve the whole corpus merely to feel complete. If the question is broad, answer the bounded part supported by the retrieved records and ask which branch to explore next.

## Do not overstate

Do not treat citations alone as knowledge application. Do not turn temporary conversation material into durable client facts. Do not claim to observe or record hidden reasoning; record visible searches, records, tool calls, and answers instead.