---
name: marketing-kb-grounded-reasoning
description: Retrieve and apply approved marketing knowledge through
  OpenKnowledge MCP before answering substantive marketing questions.
---
# Marketing knowledge grounded reasoning

Use this skill when a consultant asks a substantive marketing question and an approved marketing corpus is available through OpenKnowledge MCP.

## Authority and access

The approved corpus is the authority for general marketing principles. User-provided material may establish situation facts. Clearly label assumptions and inference. Do not use model memory as authority for a material marketing conclusion.

Use the corpus only through OpenKnowledge MCP. Respect the host's permitted tool set.

This release is read-only. The host or gateway should block tools that create, edit, move, or delete knowledge. Do not attempt a write operation even if a write tool is visible.

## Corpus boundary

Treat only results and records whose paths begin with `knowledge/` as marketing evidence. Discard every result outside `knowledge/`, including setup, testing, release-administration, and skill documents. Never follow an outside path to answer a marketing question.

## Route every turn

Before replying, decide whether the turn is substantive marketing, administrative, a correction, or a request to use an outside tool.

For substantive marketing turns, perform a fresh knowledge check. A previously read record may be reused only after confirming that it remains relevant. Administrative turns need no marketing retrieval.

## Retrieve and apply

1. Translate the consultant's wording into candidate marketing concepts. If the interpretation would materially change the answer, say how you understood it or ask a clarifying question.
2. Search using the original wording and useful alternatives.
3. Discard all search results outside `knowledge/`.
4. Read detailed records, not only search results. Follow navigation links where the conditions or limits need checking.
5. If the first search is weak, reformulate and try a short retrieval loop before concluding that the corpus lacks support.
6. Compare the record's conditions with established situation facts. Identify what is missing.
7. Give a direct conversational answer. Name the concepts or records that shaped it, explain what they mean here, separate facts from assumptions and inference, and ask one safest useful next question.

If no adequate authority is found, say so plainly, explain the limit, ask one focused question, and offer a safe alternative. If the answer needs outside evidence, explain what is missing and ask permission before a separately configured outside-tool step.

## Do not overstate

Do not treat citations alone as knowledge application. Do not turn temporary conversation material into durable client facts. Do not claim to observe or record hidden reasoning; record visible searches, records, tool calls, and answers instead.